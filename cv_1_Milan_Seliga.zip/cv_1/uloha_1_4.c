// Author: Milan Šeliga
#include <stdio.h>

int main(void){
    int number;
    
    scanf("%d",&number);
    printf("Druha mocnina cisla: %d je %d",number , number * number);
    return 0;
}