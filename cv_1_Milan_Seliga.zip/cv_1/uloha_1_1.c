// Author: Milan Šeliga
#include <stdio.h>

int main(void){
    printf("Hello wordl!\n");
}