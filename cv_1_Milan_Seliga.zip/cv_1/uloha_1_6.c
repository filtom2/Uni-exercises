// Author: Milan Šeliga
#include <stdio.h>

int main(void){
    printf("\\*/Toto je \"backslash\": \'\\\'\\*/\n");
}